package dao.database.object_dao;

import metier.Pilote;
import org.junit.Test;

import static org.junit.Assert.*;

public class Pilote_dao_interfaceTest {

    @Test
    public void addPilote(){
        Pilote p = new Pilote();
        Pilote_dao_interface piloteDaoInterface = DAO_factory.getPiloteDao();
        p=piloteDaoInterface.findByToken("796711149210378948885006004288173889968");
        p.setToken("");
        piloteDaoInterface.update(p);
    }

    @Test
    public void updatePilote(){
        Pilote p = DAO_factory.getPiloteDao().find("oussama_hadj-aissa@hotmail.com", "12345");
        p.setPassword("5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5");
        DAO_factory.getPiloteDao().update(p);
    }

}