package dao.database.object_dao;

import metier.Flight;
import org.junit.Test;
import utils.Search;

import java.util.List;


public class Flight_dao_interfaceTest {

    @Test
    public void addFlight(){
        Flight f = new Flight();
        f.setDeparted_aerodrome("paris");
        f.setArrival_aerodrome("alger");
        f.setRate(250);
        f.setNumber_of_seats(5);
        f.setDuration(180);
        f.setPilote(DAO_factory.getPiloteDao().find("vRA9MmoBV9FizhWTjgx3"));
        f.setDate("2019-05-01");
        String id = DAO_factory.getFlightDao().create(f);
        System.out.println(DAO_factory.getFlightDao().find(id));
    }

    @Test
    public void getFlightsPilote() {
        Flight_dao_interface dao = DAO_factory.getFlightDao();
        List<Flight> flights = dao.getFlightsPilote("vRA9MmoBV9FizhWTjgx3");
        for (Flight flight :
                flights) {
            System.out.println(flight);
        }
    }

    @Test
    public void updateFlight(){
        Flight f = DAO_factory.getFlightDao().find("l2LSm2oBZnW4zWQXEGvI");
        f.setDuration(40);
        f.setDescription("vol paris brest");
        f.setNumber_of_seats(2);
        DAO_factory.getFlightDao().update(f);
    }

    @Test
    public void deleteFlight(){
        DAO_factory.getFlightDao().delete("2KQJj2oBCPdeneTO7gHg");
    }

    @Test
    public void searchFlight(){
        Flight_dao_interface dao = DAO_factory.getFlightDao();
        Search search = new Search();
        search.setDeparted_aerodrome("pars");
        search.setNumber_of_seats(4);
        List<Flight> flights= dao.searchFlight(search);

        for (Flight f : flights) {
            System.out.println(f);
        }
    }
}