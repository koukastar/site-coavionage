package dao.database.object_dao;

import com.example.jetty_jersey.mail.MailSender;
import com.example.jetty_jersey.mail.mail_types.MailReservationPilot;
import metier.Reservation;
import metier.UserReservation;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class Reservation_dao_interfaceTest {

    @Test
    public void testreservation(){
        Reservation reservation = new Reservation();
        reservation.setFlight_id("rDzTeGoBv3U4sYNbIB3W");
        reservation.setUser_id("LnVMaWoBVZbIQ6_TmVIQ");
        reservation.setNumber_of_place(1);
        reservation.setValidate(-1);
        DAO_factory.getReservationDao().create(reservation);
    }

    @Test
    public void getFlightReservation() {
        Reservation_dao_interface dao = DAO_factory.getReservationDao();
        List<UserReservation> reservations = dao.getFlightReservation("rDzTeGoBv3U4sYNbIB3W");
        for (UserReservation r : reservations) {
            System.out.println(r);
        }
    }

    @Test
    public void getUserReservation() {
        Reservation_dao_interface dao = DAO_factory.getReservationDao();
        List<Reservation> reservations = dao.getUserReservation("f1EX6WkBftaV4XxAUGKp");
        for (Reservation r : reservations) {
            System.out.println(r);
        }
    }

    @Test
    public void validateReservation() {
        Reservation_dao_interface dao = DAO_factory.getReservationDao();
        dao.validateReservation("931teWoBPWn-QoWJhqyE");
        System.out.println(dao.find("931teWoBPWn-QoWJhqyE"));
    }

    @Test
    public void testMail() {
        Flight_dao_interface dao = DAO_factory.getFlightDao();
        User_dao_interface user_dao = DAO_factory.getUserDao();
        Reservation reservation = new Reservation();
        reservation.setUser_id("f1EX6WkBftaV4XxAUGKp");
        reservation.setFlight_id("vhBBMmoBV9FizhWTagzo");
        reservation.setValidate(0);
        reservation.setNotified(false);

        MailSender.send_msg(
                dao.find(reservation.getFlight_id()).getPilote().getEmail(),
                new MailReservationPilot(user_dao.find(reservation.getUser_id()), dao.find(reservation.getFlight_id()))
        );
    }

    @Test
    public void testfind() {
        Reservation reservation = DAO_factory.getReservationDao().find("x2dNJmoBPD_6OQcZIvLd");
        System.out.println(reservation);
    }

    @Test
    public void accepteReservation() {
        DAO_factory.getReservationDao().validateReservation("NJPafGoBYAoUqMoGZpng");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Reservation reservation = DAO_factory.getReservationDao().find("NJPafGoBYAoUqMoGZpng");
        System.out.println(reservation);
    }
}
