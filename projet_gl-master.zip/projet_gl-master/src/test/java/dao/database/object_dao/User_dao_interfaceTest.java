package dao.database.object_dao;

import metier.User;
import org.junit.Test;

import static org.junit.Assert.*;

public class User_dao_interfaceTest {

    @Test
    public void find() {
        User_dao user_dao = (User_dao) DAO_factory.getUserDao();
        User user = user_dao.find("oussama_hadj-aissa@hotmail.com", "12345");
        assertNotNull(user);
        assertEquals(user.getEmail(), "oussama_hadj-aissa@hotmail.com");
    }

    @Test
    public void findByToken() {
        User_dao_interface dao = DAO_factory.getUserDao();
        String token = "azert";

        User user = dao.find("oussama_hadj-aissa@hotmail.com", "12345");
        dao.setToken(user, token);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        User u = dao.findByToken(token);
        assertNotNull(u);

        System.out.println(u);
        dao.removeToken(token);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        User u2 = dao.findByToken(token);
        assertNull(u2);
    }

}