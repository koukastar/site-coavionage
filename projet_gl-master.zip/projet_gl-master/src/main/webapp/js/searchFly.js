var page_number = 0;
var all_data;


//JS FOR LOGIN
$('#radioBtn a').on('click', function () {
    var sel = $(this).data('title');
    var tog = $(this).data('toggle');
    $('#' + tog).prop('value', sel);

    $('a[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
    $('a[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
});

function logout() {
    console.log("logOut");
    var type = Cookies.get("type");

    console.log(type);

    $.ajax({
        type: 'GET',
        url: 'ws/logout/' + type,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        success: function (data) {
            console.log("logout success");
        },
        error: function (data) {
            console.log("erreur : \n");
            console.log(data);
            location.href = "http://localhost:8889";
        }
    });


}

function getuserByToken() {
    var type = Cookies.get("type");
    var token = Cookies.get("token");

    $.ajax({
        type: 'GET',
        url: 'ws/' + type + 's/getToken/' + token,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        success: function (data) {
            console.log(data);
            if (type == "pilote")
                location.href = "http://localhost:8889/profilePilote.html";
        },
        error: function (data) {
            console.log("erreur : \n");
            console.log(data);
            if (type == "pilote")
                location.href = "http://localhost:8889/profilePilote.html";
        }
    });
    location.href = 'UserPage.html';

}

$(document).ready(function () {
    checkLogin = function () {
        var content;
        if (Cookies.get('token')) {
            content = '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" onclick="getuserByToken()" data-toggle="modal">' +
                Cookies.get('firstName') + //TODO
                '</button>' +
                '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" id="logoute" onclick="logout()" data-toggle="modal">' +
                'logout' +
                '</button>'
        } else {
            content = '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" data-target="#mySingUpPop" data-toggle="modal">' +
                'sign in' +
                '</button>' +
                '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" id="loginModalButton" data-target="#loginModal" data-toggle="modal">' +
                'login' +
                '</button>'
        }
        $('#loginNavBar').html(content);
    };
    checkLogin();

    $("#formLogin").submit(function (event) {
        event.preventDefault();

        var email = $("#email1").val();
        console.log(email);
        var password = $("#pwd1").val();
        console.log(password);
        var type = $("#happy").val();
        console.log(type);

        var tab = {
            email: email,
            password: password
        };

        $.ajax({
            type: 'POST',
            url: 'ws/login/' + type,
            contentType: "application/json; charset=utf-8",
            dataType: 'json',

            data: JSON.stringify(tab),
            success: function (data) {
                console.log(data);
                location.href = "http://localhost:8889";
            },
            error: function (data) {
                console.log("erreur : \n");

                if (data.statusText === "OK") {
                    if (type == "pilote") {
                        location.href = "http://localhost:8889/profilePilote.html";
                    } else {
                        location.reload();
                        console.log(data);
                    }
                } else {
                    alert("erreur")
                }

            }
        });

    });

    $('#search_boutton').on('click', function () {
        var myNode = document.getElementById("search_all");
        while (myNode.firstChild) {
            myNode.removeChild(myNode.firstChild);
        }
        $('#page_search').show();

        var templateExemple = _.template($("#templateExemple").html());

        if ($('#is_ride').is(":checked")) {
            if ($('#date').val() != "" || $('#nbr_place').val() != "" || $('#departure_city').val() != "") {

                var departure_city = $(".departure_city").val();
                var date = ($(".date").val());
                var nbr_place = ($(".nbr_place").val());
                var is_ride = ($(".is_ride").val());
                var search = {
                    departure_city: departure_city,
                    date: date,
                    nbr_place: nbr_place,
                    is_ride: is_ride
                };
                console.log(search);
                $.ajax({
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    method: "GET",
                    data: JSON.stringify(search),
                    dataType: 'json',
                    url: "ws/flights/search?departed_aerodrome=" + search.departure_city + "&arrival_aerodrome=" + search.arrival_city,//avoir avec anis quelle page
                    success: function (data) {
                        if (data.length > 0) {
                            document.getElementById("search_all").style.marginTop = "50px";
                        }


                        all_data=data;
                        console.log(all_data);
                        var all_fly=6;
                        if (all_fly>all_data.length)
                        {
                            all_fly=all_data.length;
                            $("#next_page").addClass("disabled");
                            $("#last_page").addClass("disabled");
                        }
                        console.log(all_fly)
                        for (i = page_number; i < all_fly; i++) {


                            html = html + templateExemple({
                                "prix": data[i].rate,
                                "lien": "details_fly.html?id=" + data[i].id,
                                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                                "depart": all_data[i].departure_city,
                                "arrive": all_data[i].arrival_city
                            })
                        }

                        $('html, body').animate({
                            scrollTop: $("#search_all").offset().top
                        }, 1000);

                        create_Multi_image(data, html);
                    },
                    error: function (error) {
                        console.log(error)
                    }
                })

            } else {
                alert("would you please fill all fields");
            }
        } else {
            if ($('#date').val() != "" || $('#nbr_place').val() != "" || $('#departure_city').val() != "" || $('#arrival_city').val() != "") {
                var departure_city = document.getElementById("departure_city").value;
                var date = document.getElementById("date").value;
                var nbr_place = document.getElementById("nbr_place").value;
                var is_ride = document.getElementById("is_ride").value;
                var arrival_city = document.getElementById("arrival_city").value;
                console.log(arrival_city);

                var search = {
                    arrival_city: arrival_city,
                    departure_city: departure_city,
                    date: date,
                    nbr_place: nbr_place,
                    is_ride: is_ride
                };
                console.log(JSON.stringify(search));

                $.ajax({
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    method: "GET",
                    data: JSON.stringify(search),
                    dataType: 'json',
                    url: "ws/flights/search?departed_aerodrome=" + search.departure_city + "&arrival_aerodrome=" + search.arrival_city,
                    success: function (data) {
                        var html = "";
                        console.log("aaaa");
                        console.log(data);
                        if (data.length > 0) {
                            document.getElementById("search_all").style.marginTop = "50px";
                        }

                        all_data=data;
                        var all_fly=6;
                        if (all_fly>all_data.length)
                        {
                            all_fly=all_data.length;
                            $("#next_page").addClass("disabled");
                            $("#last_page").addClass("disabled");
                        }
                        console.log(all_fly)
                        for (i = page_number; i < all_fly; i++)


                            html = html + templateExemple({
                                "prix": data[i].rate,
                                "lien": "details_fly.html?id=" + data[i].id,
                                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                                "depart": all_data[i].departed_aerodrome,
                                "arrive": all_data[i].arrival_aerodrome
                            })
                        $('html, body').animate({
                            scrollTop: $("#search_all").offset().top
                        }, 1000);

                        create_Multi_image(data, html);
                    },
                    error: function (error) {
                        console.log(error)
                    }
                })
            } else {
                alert("would you please fill all fields");
            }
        }
    })
});


function page_next(event) {
    console.log(all_data.length);
    var myNode = document.getElementById("search_all");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
        console.log("je suprime");
    }
    $("#previous_page").removeClass("disabled");
    $("#first_page").removeClass("disabled");
    event.preventDefault();
    page_number++;
    var rest;
    var disable = 0;
    if ((all_data.length - ((page_number) * 6) < 7) && (all_data.length - ((page_number) * 6) > 0)) {
        rest = all_data.length - (page_number) * 6;
        disable = 1;
    } else {
        if (all_data.length - ((page_number) * 6) > 6) {
            rest = 6;
        } else {
            rest = -1;
        }
    }
    var templateExemple = _.template($("#templateExemple").html());
    html = "";

    {
        for (i = page_number * 6; i < page_number * 6 + rest; i++)
            html = html + templateExemple({
                "prix": all_data[i].rate,
                "lien": "details_fly.html?id=" + all_data[i].id,
                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                "depart": all_data[i].departed_aerodrome,
                "arrive": all_data[i].arrival_aerodrome
            })
        create_Multi_image(all_data, html);
    }
    if (disable == 1) {
        $("#next_page").addClass("disabled");
        $("#last_page").addClass("disabled");
        console.log("desabled")
    }
}


function page_previous(event) {
    var myNode = document.getElementById("search_all");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
        console.log("je suprime");
    }
    $("#next_page").removeClass("disabled");
    $("#last_page").removeClass("disabled");
    event.preventDefault();
    if (page_number > 0)
        page_number--;
    var rest;
    var disable = 0;
    if ((all_data.length - ((page_number) * 6) < 7) && (all_data.length - ((page_number) * 6) > 0)) {
        rest = all_data.length - (page_number) * 6;

    } else {
        if (all_data.length - ((page_number) * 6) > 6) {
            rest = 6;
        } else {
            rest = -1;
        }
    }
    var templateExemple = _.template($("#templateExemple").html());
    html = "";

    {
        for (i = page_number * 6; i < page_number * 6 + rest; i++)
            html = html + templateExemple({
                "prix": all_data[i].rate,
                "lien": "details_fly.html?id=" + all_data[i].id,
                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                "depart": all_data[i].departed_aerodrome,
                "arrive": all_data[i].arrival_aerodrome
            })
        create_Multi_image(all_data, html);
    }
    if (page_number == 0)
        disable = 1;
    if (disable == 1) {
        $("#previous_page").addClass("disabled");
        $("#first_page").addClass("disabled");
    }
}

function page_first(event) {
    var myNode = document.getElementById("search_all");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
        console.log("je suprime");
    }
    $("#previous_page").addClass("disabled");
    $("#first_page").addClass("disabled");
    $("#last_page").removeClass("disabled");
    $("#next_page").removeClass("disabled");
    event.preventDefault();
    page_number = 0;
    var rest;
    var disable = 0;
    if ((all_data.length - ((page_number) * 6) < 7) && (all_data.length - ((page_number) * 6) > 0)) {
        rest = all_data.length - (page_number) * 6;
        disable = 1;
    } else {
        if (all_data.length - ((page_number) * 6) > 6) {
            rest = 6;
        } else {
            rest = -1;
        }
    }
    var templateExemple = _.template($("#templateExemple").html());
    html = "";
    {
        for (i = page_number * 6; i < page_number * 6 + rest; i++)
            html = html + templateExemple({
                "prix": all_data[i].rate,
                "lien": "details_fly.html?id=" + all_data[i].id,
                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                "depart": all_data[i].departed_aerodrome,
                "arrive": all_data[i].arrival_aerodrome
            })
        create_Multi_image(all_data, html);
    }
    if (disable == 1) {
        $("#next_page").addClass("disabled");
        $("#last_page").addClass("disabled");
        console.log("desabled")
    }
}

function page_last(event) {
    var myNode = document.getElementById("search_all");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
        console.log("je suprime");
    }
    $("#previous_page").removeClass("disabled");
    $("#first_page").removeClass("disabled");
    $("#last_page").addClass("disabled");
    $("#next_page").addClass("disabled");
    event.preventDefault();
    var dem = all_data.length % 6;
    page_number = (all_data.length - dem) / 6;
    var rest;
    var disable = 0;
    if ((all_data.length - ((page_number) * 6) < 7) && (all_data.length - ((page_number) * 6) > 0)) {
        rest = all_data.length - (page_number) * 6;
        disable = 1;
    } else {
        if (all_data.length - ((page_number) * 6) > 6) {
            rest = 6;
        } else {
            rest = -1;
        }
    }
    var templateExemple = _.template($("#templateExemple").html());
    html = "";

    {
        for (i = page_number * 6; i < page_number * 6 + rest; i++)
            html = html + templateExemple({
                "prix": all_data[i].rate,
                "lien": "details_fly.html?id=" + all_data[i].id,
                "image": "ws/pilotes/image/flight_" + all_data[i].id,
                "depart": all_data[i].departed_aerodrome,
                "arrive": all_data[i].arrival_aerodrome
            })
        create_Multi_image(all_data, html);
    }
    if (disable == 1) {
        $("#next_page").addClass("disabled");
        $("#last_page").addClass("disabled");
        console.log("desabled")
    }
}

function create_Multi_image(data, html) {
    div = "#" + "search_all";
    var $log = $(div),
        html_parsed = $.parseHTML(html);
    $log.append(html_parsed);
}

