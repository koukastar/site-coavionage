function activer() {
    var check = document.getElementById('CheckRide');
    var ArrivalCity = document.getElementById('ArrivalCity');

    if (check.checked) {
        ArrivalCity.disabled = true;
        ArrivalCity.value = null;
    }
    else {
        ArrivalCity.disabled = false;
    }
}

$("form").on("submit", function (event) {
    event.preventDefault();

    var departed_aerodrome1 = document.getElementById("DepartureCity").value;
    var arrival_aerodrome1 = document.getElementById("ArrivalCity").value;
    var date1 = document.getElementById("date").value;
    var rate1 = document.getElementById("price").value;
    var number_of_seats1 = document.getElementById("passengers").value;
    var plan_type1 = document.getElementById("model").value;
    var duration1 = document.getElementById("duration").value;
    var description1 = document.getElementById("description").value;

    var flight = {
        departed_aerodrome: departed_aerodrome1,
        arrival_aerodrome: arrival_aerodrome1,
        date: date1,
        rate: rate1,
        number_of_seats: number_of_seats1,
        plan_type: plan_type1,
        duration: duration1,
        description: description1
    };

    flight = JSON.stringify(flight);
    var tokenPilote = Cookies.get('token');
    console.log(tokenPilote);

    $.ajax({
        url: "http://localhost:8889/ws/flights/create/" + tokenPilote,
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: flight,
        success: function (data) {
            console.log(data);

            $('input[name="file"]').each(function (index, value) {
                var file = value.files[0];
                if (file) {
                    var formData = new FormData();
                    formData.append('file', file);
                    $.ajax({
                        url: 'ws/pilotes/image/upload/flight_' + data.id,
                        type: 'POST',
                        data: formData,
                        contentType: 'multipart/form-data',
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (data, textStatus, jqXHR) {
                            location.href = 'listFlight.html';
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                        }
                    });
                }
            });

            //location.href = 'listFlight.html';
        },
        error: function (da) {
            console.log("erreur : \n");
            console.log(da);
            //location.href = 'listFlight.html';
        }
    });
});




      