
$(function() {
    $("#example").DataTable();

    var testDataUrl = "/users"
    document.getElementById("demo").innerHTML = testDataUrl;


    $("#loadData").click(function() {
        loadData();
    });

    $( document ).ready(function( $ ){loadData()});



    function loadData() {
        $.ajax({
            type: 'GET',
            url: 'ws'+testDataUrl,
            dataType: 'json',

            
            success: function (data) {
                myJsonData = data;
                populateDataTable(myJsonData);
            },
            error: function (e) {
                console.log("There was an error with your request...");
                console.log("error: " + JSON.stringify(e));
            }
        });

    }


    // populate the data table with JSON data
    function populateDataTable(data) {

        console.log("populating data table...");
        // clear the table before populating it with more data
        $("#example").DataTable().clear();

        var length = Object.keys(data).length;

        for(var i = 0; i < length+1; i++) {


           var customer = data[i];

           // You could also use an ajax property on the data table initialization
            $('#example').dataTable().fnAddData(

                [   customer.email,
                    customer.password,
                    customer.first_name,
                    customer.name,
                    customer.id
                ]
            );
        }
    }
});


$("#add_user").click(function () {
    alert("hello");

});


