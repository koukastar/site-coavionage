var id_flight;
var nbr_place;
var idUser;
$.urlParam = function (name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}
var id_plan_type = document.getElementById("id_plan_type");
var id_num_seat = document.getElementById("id_num_seat");
var id_departed = document.getElementById("id_departed");
var id_arrival = document.getElementById("id_arrival");
var id_date = document.getElementById("id_date");
var id_place_meeting = document.getElementById("id_place_meeting");
var id_duration = document.getElementById("id_duration");
var id_rate = document.getElementById("id_rate");

var id = ($.urlParam('id'));
id_flight = id;

$.ajax({
    headers: {
        'Content-Type': 'application/json'
    },
    method: "GET",
    dataType: 'json',
    url: "/ws/flights/flight/" + id,
    success: function (data) {
        console.log("done", data);
        document.getElementById("id_plan_type").innerHTML = data.plan_type;
        document.getElementById("id_num_seat").innerHTML = data.number_of_seats;
        nbr_place = data.number_of_seats;
        id_flight = data.id;
        document.getElementById("id_departed").innerHTML = data.departed_aerodrome;
        document.getElementById("id_arrival").innerHTML = data.arrival_aerodrome;
        document.getElementById("id_date").innerHTML = data.date;
        document.getElementById("id_place_meeting").innerHTML = data.place_of_meeting;
        document.getElementById("id_duration").innerHTML = data.duration;
        document.getElementById("id_rate").innerHTML = data.rate;
        document.getElementById("description").innerHTML = data.description;
        console.log(data);

        var templateExemple = _.template($("#templateExemple").html());
        html = "";
        html = html + templateExemple({
            "image1": "ws/pilotes/image/flight_" + id_flight,
            "image2": "ws/pilotes/image/pilote_" + data.pilote.id
        });
        div = "#" + "resultat";
        var $log = $(div),
            html_parsed = $.parseHTML(html);
        $log.append(html_parsed);
    },
    error: function (data) {
        location.href = "http://localhost:8889";
    }

})
var token = Cookies.get("token");
var type = Cookies.get("type");

function myFunction() {
    if (Cookies.get('token')) {
        var a = $("#select :selected").text();
        console.log(a);
        var c = parseInt(a, 10);
        var d = parseInt(nbr_place, 10);
        if (c > d) {
            $("#Modal_not_enought").modal();
            return 0;
        }
        if (a != "Number of Persons:") {

            $.ajax({
                headers: {
                    'Content-Type': 'application/json'
                },
                method: "GET",
                dataType: 'json',
                url: 'ws/' + type + 's/getToken/' + token,
                success: function (data1) {
                    console.log(data1.id);
                    idUser = data1.id;

                    $.ajax({
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        method: "POST",
                        dataType: 'json',
                        url: "ws/reservations/createReservation?idUser=" + idUser + "&nbPlace=" + a + "&idFlight=" + id_flight,
                        success: function (data1) {
                            //$("#modal_reservation").modal();
                        }
                    });
                    $("#modal_reservation").modal();
                }
            });
        } else {
            console.log("choisit le nbr de personne");
            $("#loginModal1").modal();
        }
    }
    else {
        $("#loginModal").modal();
    }
}
