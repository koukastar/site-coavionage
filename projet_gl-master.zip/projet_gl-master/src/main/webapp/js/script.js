var templateExemple= _.template($("#templateExemple").html());
var departure_city = document.getElementById("departure_city").value;
var date = document.getElementById("date").value;
var nbr_place = document.getElementById("nbr_place").value;
var is_ride = document.getElementById("is_ride").value;
var arrival_city= document.getElementById("arrival_city").value;


$("#usersbtn").click( function () {
	var search = {
		arrival_city: arrival_city,
		departure_city: departure_city,
		date: date,
		nbr_place: nbr_place,
		is_ride: is_ride
	}
	$.ajax({
		headers: {
			'Content-Type': 'application/json'
		},
		method: "GET",
		data: JSON.stringify(search),
		dataType: 'json',
		url: "ws/flights/searchFly",
		success: function (data) {
			var html="";
			for (i=0;i<data.length;i++)
			html = html + templateExemple({
				"prix": data[i].departed_aerodrome
			})

			create_Multi_image(data, html);
		},
		error: function (error) {
			console.log(error)
		}
	})
	function create_Multi_image(data, html) {
		div = "#" + "search_all";
		var $log = $(div),
		html_parsed = $.parseHTML(html);
		$log.append(html_parsed);
	}});