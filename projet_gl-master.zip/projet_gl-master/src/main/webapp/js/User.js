var information;
var accepted = [];
var ondemande = [];
var expiration = [];
var reservation;
var templateDemande = _.template($("#templateDemande").html());

html = "";
var allDemande = $("#allDemand");

function getuserByToken() {
    var type = Cookies.get("type");
    var token = Cookies.get("token");
    console.log(type);
    var flyid;
    $.ajax({
        type: 'GET',
        async: false,
        url: 'ws/' + type + 's/getToken/' + token,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (data) {
            //console.log(data);
            information = data;
            $("#imguser").attr("src", "http://localhost:8889/ws/pilotes/image/user_" + information.id);
            $("#firstName").val(information.first_name);
            $("#inputEmail").val(information.email);
            $("#lastName").val(information.name);
            $.ajax({
                type: 'GET',
                async: false,
                url: 'ws/reservations/user/' + information.id,
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                success: function (data) {

                    table_flight = data;
                    if (table_flight.length > 0) {
                        var html = "";
                        for (i = 0; i < table_flight.length; i++) {
                            //console.log(table_flight[i].flight_id)
                            $.ajax({
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                method: "GET",
                                dataType: 'json',
                                async: false,
                                url: "/ws/flights/flight/" + table_flight[i].flight_id,
                                success: function (data) {
                                    console.log(data)
                                    var date1 = new Date(data.date);
                                    if (table_flight[i].validate == -1 && date1 > Date.now())
                                        ondemande.push(data);
                                    if (table_flight[i].validate == 1 && date1 > Date.now()) {
                                        accepted.push(data);
                                    }
                                    if (date1 < Date.now() && table_flight[i].validate == 1) {
                                        console.log(date1)
                                        expiration.push(data);
                                    }
                                }
                            });
                            resultat = html
                        }
                    }
                },
                error: function () {
                    console.log("errrroooor")
                }
            })
        },
        error: function (data) {
            console.log("erreur : \n");
            location.href = "http://localhost:8889";
            console.log(data);
        }
    });
}

//getuserByToken();
$(function () {
    $(document).on("change", ".uploadFile", function () {
        var uploadFile = $(this);
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test(files[0].type)) { // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function () { // set image data as background of div
                $("#imguser").attr("src", this.result);
            }
        }
    });
});

function edit_information() {
    getuserByToken();
    $('input[name="file"]').each(function (index, value) {
        var file = value.files[0];
        if (file) {
            var formData = new FormData();
            formData.append('file', file);
            $.ajax({
                url: 'ws/pilotes/image/upload/user_' + information.id,
                type: 'POST',
                data: formData,
                contentType: 'multipart/form-data',
                cache: false,
                contentType: false,
                processData: false,
                success: function (data, textStatus, jqXHR) {
                    var message = jqXHR.responseText;
                    location.reload();
                    console.log(message);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                }
            });
        }
    });
}
getuserByToken();
for (i = 0; i < ondemande.length; i++) {
    html = html + templateDemande({
        "reservation_id": ondemande[i].id,
        "nom": ondemande[i].departed_aerodrome,
        "email": ondemande[i].arrival_aerodrome,
        "prenom": ondemande[i].date,
        "zaki": ondemande[i].duration,
        "rate": ondemande[i].rate,

    });
}
html1 = ""
for (i = 0; i < accepted.length; i++) {

    html1 = html1 + templateDemande({
        "reservation_id": accepted[i].id,
        "nom": accepted[i].departed_aerodrome,
        "email": accepted[i].arrival_aerodrome,
        "prenom": accepted[i].date,
        "zaki": accepted[i].duration,
        "rate": accepted[i].rate,
    });
}
html_parsed = $.parseHTML(html);
allDemande.append(html_parsed);

var validated = $("#validated");
html_parsed1 = $.parseHTML(html1);
validated.append(html_parsed1);
html2 = "";
for (i = 0; i < expiration.length; i++)
{
            html2 = html2 + templateDemande({
                "reservation_id": expiration[i].id,
                "nom": expiration[i].departed_aerodrome,
                "email": expiration[i].arrival_aerodrome,
                "prenom": expiration[i].date,
                "zaki": expiration[i].duration,
                "rate": expiration[i].rate,
            });
    }
var allPassager = $("#allPassager");
html_parsed2 = $.parseHTML(html2);
allPassager.append(html_parsed2);



