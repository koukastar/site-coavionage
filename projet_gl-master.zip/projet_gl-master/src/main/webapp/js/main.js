

checkLogin = function () {
    var content;
    if (Cookies.get('token')) {
        content = '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight"  onclick="getuserByToken()" data-toggle="modal">' +
            Cookies.get('firstName') + //TODO
            '</button>' +
            '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" id="logoute" onclick="logout()" data-toggle="modal">' +
            'logout' +
            '</button>'
    } else {
        content = '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" data-target="#mySingUpPop" data-toggle="modal">' +
            'sign in' +
            '</button>' +
            '<button class="btn btn-light btn-md my-2 my-sm-0 ml-3 btn-flight" id="loginModalButton" data-target="#loginModal" data-toggle="modal">' +
            'login' +
            '</button>'
    }
    $('#loginNavBar').html(content);
}
checkLogin();

$("#formLogin").submit(function (event) {
    event.preventDefault();

    var email = $("#email1").val();
    console.log(email);
    var password = $("#pwd1").val();
    console.log(password);
    var type = $("#happy").val();
    console.log(type);

    var tab = {
        email: email,
        password: password
    };

    $.ajax({
        type: 'POST',
        url: 'ws/login/' + type,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        data: JSON.stringify(tab),
        success: function (data) {
            console.log(data);
            location.href = "http://localhost:8889";
        },
        error: function (data) {
            console.log("erreur : \n");
            if (data.statusText === "OK")
                if(type === "pilote"){
                    location.href = "http://localhost:8889/profilePilote.html";
                }else{location.reload();
                    console.log(data);}

        }
    });

});
