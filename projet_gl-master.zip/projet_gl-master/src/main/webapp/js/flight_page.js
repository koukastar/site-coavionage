console.log("hello");
var donnee;
$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}

var id=($.urlParam('id'));
console.log(id);

function fill_both_table() {
    $.ajax({
        headers: {
            'Content-Type': 'application/json'
        },
        method: "GET",
        dataType: 'json',

        url: "/ws/flights/demandeur/" + id,
        success: function (data) {
            console.log(data);
            var html = "";
            var html1 = "";
            var templateDemande = _.template($("#templateDemande").html());
            var templatePassage = _.template($("#templatePassage").html());

            for (i = 0; i < data.length; i++) {
                if (data[i].validate == -1) {
                    html = html + templateDemande({
                        "reservation_id": data[i].reservation_id,
                        "nom": data[i].user_first_name,
                        "email": data[i].user_email,
                        "prenom": data[i].user_name
                    })

                }
                if (data[i].validate == 1) {
                    html1 = html1 + templatePassage({
                        "reservation_id": data[i].reservation_id,
                        "nom": data[i].user_first_name,
                        "email": data[i].user_email,
                        "prenom": data[i].user_name
                    })

                }
                console.log(data[i].first_name)
            }
            var allDemande = $("#allDemand");
            var allPassenger = $("#allPassager");
            html_parsed = $.parseHTML(html);
            html_parsed1 = $.parseHTML(html1);

            allDemande.append(html_parsed);
            allPassenger.append(html_parsed1);

            console.log(html);
        },
        error: function () {
        }
    });

}


fill_both_table();
$.ajax({
    headers: {
        'Content-Type': 'application/json'
    },
    method: "GET",
    dataType: 'json',
    url: "/ws/flights/flight/" + id,
    success: function (data) {
        console.log("done", data);
        document.getElementById("id_plan_type").innerHTML=data.plan_type;
        document.getElementById("id_num_seat").innerHTML=data.number_of_seats;
        nbr_place=data.number_of_seats;
        id_flight=data.id;
        document.getElementById("id_departed").innerHTML=data.departed_aerodrome;
        document.getElementById("id_arrival").innerHTML=data.arrival_aerodrome;
        document.getElementById("id_date").innerHTML=data.date;
        document.getElementById("id_place_meeting").innerHTML=data.place_of_meeting;
        document.getElementById("id_duration").innerHTML=data.duration;
        document.getElementById("id_rate").innerHTML =data.rate;

    },
    error: function (data) {
        location.href = "http://localhost:8889";}

})




function accepte(x) {
    var parent = x.parentNode;
    parent = parent.parentNode;
    var identidiant_res=($(parent).attr('id'));

    $.ajax({
        url: "/ws/reservations/validete?idReservation="+identidiant_res,
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        success: function (data) {
            console.log(data);
        },
        error: function (da) {
            console.log("erreur : \n");
            console.log(da);
        }
    });
    var table = parent.parentNode;
    console.log(table);
    console.log(parent.rowIndex);

    table.deleteRow(parent.rowIndex - 1);

}

function refuse(x) {
    var parent = x.parentNode;
    parent = parent.parentNode;
    var identidiant_res=($(parent).attr('id'));

    $.ajax({
        url: "/ws/reservations/unvalidate?idReservation="+identidiant_res,
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        success: function (data) {
            console.log(data);
        },
        error: function (da) {
            console.log("erreur : \n");
            console.log(da);
        }
    });
    var table = parent.parentNode;
    console.log(table);
    console.log(parent.rowIndex);

    table.deleteRow(parent.rowIndex - 1);


}