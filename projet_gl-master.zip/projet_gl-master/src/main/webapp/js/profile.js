var information;
var token

function getuserByToken() {
    var type = Cookies.get("type");
    token = Cookies.get("token");
    console.log(type);

    $.ajax({
        type: 'GET',
        url: 'ws/' + type + 's/getToken/' + token,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        success: function (data) {
            console.log(data);
            information = data;
            $("#imgpilote").css("background-image", "url(http://localhost:8889/ws/pilotes/image/pilote_" + information.id + ")");
            $("#firstName").val(information.first_name);
            $("#email").val(information.email);
            $("#description").val(information.description);
            $("#lastName").val(information.name);
            $("#nombre_heure").val(information.hours_of_flight);
        },
        error: function (data) {
            console.log("erreur : \n");
            location.href = "http://localhost:8889";

            console.log(data);
        }
    });

}

$(document).ready(function () {
    getuserByToken();
})


//$(".imgAdd").append("<img id='theImg' src='ws/pilotes/image/pilote_'+information.id+ '/>' ");
//$(".imgAdd").attr("src", src1);
//$(".imgdwld").attr("src", src1);
$(".imgAdd").click(function () {
    $(this).closest(".row").find('.imgAdd').before('<div class="col-sm-2 imgUp"><div class="imagePreview"></div><label class="btn btn-primary">Upload<input type="file" class="uploadFile img" value="Upload Photo" style="width:0px;height:0px;overflow:hidden;"></label><i class="fa fa-times del"></i></div>');
});

$(function () {
    $(document).on("change", ".uploadFile", function () {
        var uploadFile = $(this);
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test(files[0].type)) { // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function () { // set image data as background of div
                //alert(uploadFile.closest(".upimage").find('.imagePreview').length);
                uploadFile.closest(".imgUp").find('.imagePreview').css("background-image", "url(" + this.result + ")");
            }
        }
    });
});


function save() {
    if (document.getElementById("lastName").value == "" || document.getElementById("lastName").value == "" ||
        document.getElementById("email").value == "") {
        alert("would you reset all fill")
        return 0;
    }

    var pilote;

    $('input[name="file"]').each(function (index, value) {
        var file = value.files[0];
        if (file) {
            var formData = new FormData();
            formData.append('file', file);
            $.ajax({
                url: 'ws/pilotes/image/upload/pilote_' + information.id,
                type: 'POST',
                data: formData,
                contentType: 'multipart/form-data',
                cache: false,
                contentType: false,
                processData: false,
                success: function (data, textStatus, jqXHR) {
                    location.reload();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                }
            });
        }
    });

    var nom = document.getElementById("lastName").value;
    var prenom = document.getElementById("firstName").value;
    var email = document.getElementById("email").value;
    var password = information.password;
    var token = information.token;
    var number_of = document.getElementById("nombre_heure").value;
    pilote = {
        id: information.id,
        name: nom,
        first_name: prenom,
        email: email,
        hours_of_flight: number_of,
        token: token,
        password: information.password,
        type: information.type
    };
    pilote = JSON.stringify(pilote);
    console.log(pilote);
    $.ajax({
        url: "ws/pilotes/update",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: pilote,
        success: function (data) {
            console.log(data);
            location.reload();
        },
        error: function (data) {
            console.log("erreur : \n");
            console.log(data);
        }
    });
}




