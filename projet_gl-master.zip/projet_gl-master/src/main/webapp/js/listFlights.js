$(function() {
    $("#example").DataTable();
    $("#loadData").click(function() {
        loadData();
    });

    $( document ).ready(function( $ ){loadData()});

    var tokenPilote;
    var type = Cookies.get("type");
    console.log(type);

    if (type== "pilote"){
        tokenPilote=Cookies.get("token");
    }
    console.log(type);
    console.log(tokenPilote);

    function loadData() {
        $.ajax({
            type: 'GET',
            url: 'ws'+"/flights/getPilotes/"+tokenPilote,
            dataType: 'json',
            success: function (data) {
                myJsonData = data;
                populateDataTable(myJsonData);
            },
            error: function (e) {
                console.log("There was an error with your request...");
                console.log("error: " + JSON.stringify(e));
            }
        });
    }

    function populateDataTable(data) {
        $("#example").DataTable().clear();

        var length = Object.keys(data).length;

        for(var i = 0; i < length; i++) {
            console.log(data[i].id);
            console.log(data[i]);
            var flight = data[i];
            var b = '<a class="btn btn-flight" href="flightPage.html?id='+ data[i].id + '"> view </a>';
            $('#example').dataTable().fnAddData(
                [   flight.departed_aerodrome,
                    flight.arrival_aerodrome,
                    flight.date,
                    flight.rate,
                    flight.duration,
                    b,
                ]
            );
        }
    }
});




