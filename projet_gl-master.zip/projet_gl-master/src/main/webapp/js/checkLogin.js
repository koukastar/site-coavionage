function logout() {
    console.log("logOut");
    var type = Cookies.get("type");

    console.log(type);

    $.ajax({
        type: 'GET',
        url: 'ws/logout/' + type,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        success: function (data) {
            console.log("logout success");
        },
        error: function (data) {
            console.log("erreur : \n");
            console.log(data);
            location.href = "http://localhost:8889";
        }
    });
}


            $(document).ready(function ()
            {
                checkLoginPilote = function () {
                    console.log(Cookies.get("token"));
                    if (Cookies.get('token') && Cookies.get('type') == 'pilote') {
                        console.log('Welcomm '+Cookies.get('type'));
                }else{
                        location.href="http://localhost:8889/";

                    }
                };
                checkLoginPilote();
            });
