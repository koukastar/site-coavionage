$(document).ready(function () {

    var type = Cookies.get("type");
    var token = Cookies.get("token");

    $.ajax({
        type: 'GET',
        url: 'ws/'+type+'s/getToken/'+token,
        contentType: "application/json; charset=utf-8",
        dataType: 'json',

        success: function (data) {
            console.log(data);
            donnee = data;
            var html = "";
            var templateProfilePilote = _.template($("#templateProfilePilote").html());

            for (i = 0; i < data.length; i++)
                html=html+templateDemande({
                    "nom": data[i].first_name,
                    "email": data[i].email,
                    "prenom": data[i].name
                })

            var allPassager= $("#allPassager");
            html_parsed = $.parseHTML(html);
            allPassager.append(html_parsed);
        },
        error: function (error) {
            console.log(error)
        }
    })
});


