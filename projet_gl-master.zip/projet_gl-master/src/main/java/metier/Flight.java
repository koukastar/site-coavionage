package metier;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Flight implements Metier {

    private String id;
    private String departed_aerodrome;
    private String arrival_aerodrome;
    private int duration;
    private int number_of_seats;
    private double rate;
    private String place_of_meeting;
    private String date;
    private String description;
    private String plan_type;
    private Pilote pilote;
    private ArrayList<Reservation> reservations;
    private ArrayList<String> images;
    private boolean notified;


    public Flight() {
        reservations = new ArrayList<>();
    }

    public String getDeparted_aerodrome() {
        return departed_aerodrome;
    }

    public void setDeparted_aerodrome(String departed_aerodrome) {
        this.departed_aerodrome = departed_aerodrome;
    }

    public String getArrival_aerodrome() {
        return arrival_aerodrome;
    }

    public void setArrival_aerodrome(String arrival_aerodrome) {
        this.arrival_aerodrome = arrival_aerodrome;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getNumber_of_seats() {
        return number_of_seats;
    }

    public void setNumber_of_seats(int number_of_seats) {
        this.number_of_seats = number_of_seats;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getPlace_of_meeting() {
        return place_of_meeting;
    }

    public void setPlace_of_meeting(String place_of_meeting) {
        this.place_of_meeting = place_of_meeting;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlan_type() {
        return plan_type;
    }

    public void setPlan_type(String plan_type) {
        this.plan_type = plan_type;
    }

    public Pilote getPilote() {
        return pilote;
    }

    public void setPilote(Pilote pilote) {
        this.pilote = pilote;
    }

    public ArrayList<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(ArrayList<Reservation> reservations) {
        this.reservations = reservations;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "id='" + id + '\'' +
                ", departed_aerodrome='" + departed_aerodrome + '\'' +
                ", arrival_aerodrome='" + arrival_aerodrome + '\'' +
                ", duration=" + duration +
                ", number_of_seats=" + number_of_seats +
                ", rate=" + rate +
                ", place_of_meeting='" + place_of_meeting + '\'' +
                ", date=" + date +
                ", description='" + description + '\'' +
                ", plan_type='" + plan_type + '\'' +
                ", pilote=" + pilote +
                ", reservations=" + reservations +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flight flight = (Flight) o;
        return Objects.equals(description, flight.description);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<String> getImages() {
        return images;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

    public boolean isNotified() {
        return notified;
    }

    public void setNotified(boolean notified) {
        this.notified = notified;
    }
}




