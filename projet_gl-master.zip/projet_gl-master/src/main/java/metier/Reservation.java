package metier;

import java.util.Objects;

public class Reservation implements Metier {

    private String id;
    private int number_of_place;
    private String flight_id;
    private String user_id;
    private int validate;
    private boolean notified;

    public Reservation(){}

    public Reservation(int number_of_place, String flight_id, String user_id) {
        this.number_of_place = number_of_place;
        this.flight_id = flight_id;
        this.user_id = user_id;
        this.validate = -1;
    }

    public int getNumber_of_place() {
        return number_of_place;
    }

    public void setNumber_of_place(int number_of_place) {
        this.number_of_place = number_of_place;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getValidate() {
        return validate;
    }

    public void setValidate(int validate) {
        this.validate = validate;
    }

    public String getFlight_id() {
        return flight_id;
    }

    public void setFlight_id(String flight_id) {
        this.flight_id = flight_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "id='" + id + '\'' +
                ", number_of_place=" + number_of_place +
                ", flight_id='" + flight_id + '\'' +
                ", user_id='" + user_id + '\'' +
                ", validate=" + validate +
                '}';
    }

    public boolean isNotified() {
        return notified;
    }

    public void setNotified(boolean notified) {
        this.notified = notified;
    }
}

