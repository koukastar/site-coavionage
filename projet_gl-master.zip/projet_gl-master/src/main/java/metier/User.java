package metier;

import java.util.ArrayList;

public class User extends Person{

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", first_name='" + first_name + '\'' +
                ", name='" + name + '\'' +
                ", token='" + token + '\'' +
                ", type='" + type + '\'' +
                '}';
    }

}
