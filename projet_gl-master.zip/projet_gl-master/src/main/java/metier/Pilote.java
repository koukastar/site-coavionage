package metier;

import java.util.ArrayList;

public class Pilote extends Person{

    private double hours_of_flight;

    private ArrayList<Flight> flights;

    private String image;

    public double getHours_of_flight() {
        return hours_of_flight;
    }

    public void setHours_of_flight(double hours_of_flight) {
        this.hours_of_flight = hours_of_flight;
    }

    public ArrayList<Flight> getFlights() {
        return flights;
    }

    public void setFlights(ArrayList<Flight> flights) {
        this.flights = flights;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Pilote{" +
                "id='" + id + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", first_name='" + first_name + '\'' +
                ", hours_of_flight=" + hours_of_flight +
                ", flights=" + flights +
                ", token='" + token + '\'' +
                ", type='" + type + '\'' +
                ", image='" + image + '\'' +
                '}';
    }

}
