package metier;

public interface Metier {

    String getId();

    void setId(String id);

}
