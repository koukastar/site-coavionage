package utils;

public class Search {

    private String departed_aerodrome;

    private String arrival_aerodrome;

    private int number_of_seats;

    private String date;

    public String getDeparted_aerodrome() {
        return departed_aerodrome;
    }

    public void setDeparted_aerodrome(String departed_aerodrome) {
        this.departed_aerodrome = departed_aerodrome;
    }

    public String getArrival_aerodrome() {
        return arrival_aerodrome;
    }

    public void setArrival_aerodrome(String arrival_aerodrome) {
        this.arrival_aerodrome = arrival_aerodrome;
    }

    public int getNumber_of_seats() {
        return number_of_seats;
    }

    public void setNumber_of_seats(int number_of_seats) {
        this.number_of_seats = number_of_seats;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getQuery(){
        StringBuilder stringBuilder = new StringBuilder();
        if (departed_aerodrome != null)
            stringBuilder.append("departed_aerodrome:").append(departed_aerodrome).append("~1");
        if (arrival_aerodrome != null && !arrival_aerodrome.equals(""))
            stringBuilder.append(" AND arrival_aerodrome:").append(arrival_aerodrome).append("~1");

        System.out.println(stringBuilder);
        return stringBuilder.toString();
    }

}
