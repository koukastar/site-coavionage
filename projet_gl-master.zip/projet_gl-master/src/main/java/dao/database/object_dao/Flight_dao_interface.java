package dao.database.object_dao;

import metier.Flight;
import utils.Search;

import java.util.List;

public interface Flight_dao_interface extends Dao_interface<Flight> {

    List<Flight> getFlightsPilote(String pilote_id);

    List<Flight> searchFlight(Search search);

    boolean setNotified(Flight flight);

    boolean setNotified(String flight_id);
}
