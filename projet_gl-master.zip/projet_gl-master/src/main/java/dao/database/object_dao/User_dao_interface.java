package dao.database.object_dao;

import metier.User;

public interface User_dao_interface extends Person_dao_interface<User> {


}
