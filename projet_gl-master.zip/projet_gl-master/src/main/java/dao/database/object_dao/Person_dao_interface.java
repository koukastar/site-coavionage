package dao.database.object_dao;


import metier.Person;

public interface Person_dao_interface<T extends Person> extends Dao_interface<T> {

    T find(String email, String password);

    void setToken(String user_id, String token);

    void setToken(T person, String token);

    T removeToken(String token);

    T findByToken(String token);
}
