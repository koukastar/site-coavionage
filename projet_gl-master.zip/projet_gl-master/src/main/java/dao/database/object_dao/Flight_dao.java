package dao.database.object_dao;

import dao.database.DataBase;
import metier.Flight;
import org.elasticsearch.action.search.SearchResponse;

import org.elasticsearch.index.query.*;
import utils.Search;

import java.util.List;

public class Flight_dao extends DAO<Flight> implements Flight_dao_interface {

    Flight_dao(DataBase db) {
        super(db,"flights", "flight", Flight.class);
    }

    @Override
    public List<Flight> getFlightsPilote(String pilote_id){
        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(QueryBuilders.matchQuery("pilote.id", pilote_id))
                .get();
        return mapHits(response);
    }

    @Override
    public List<Flight> searchFlight(Search search){
        RangeQueryBuilder query = new RangeQueryBuilder("number_of_seats")
                .gte(search.getNumber_of_seats());

        QueryBuilder query2 = new QueryStringQueryBuilder(search.getQuery());

        BoolQueryBuilder q = QueryBuilders.boolQuery()
                .filter(query2)
                .filter(query);

        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(q)
                .get();
        return mapHits(response);
    }

    @Override
    public boolean setNotified(Flight flight){
        flight.setNotified(true);
        return update(flight);
    }

    @Override
    public boolean setNotified(String flight_id){
        return setNotified(find(flight_id));
    }


}
