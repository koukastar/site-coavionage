package dao.database.object_dao;

import metier.Flight;
import metier.Reservation;
import metier.User;
import metier.UserReservation;

import java.util.List;

public interface Reservation_dao_interface extends Dao_interface<Reservation> {

    List<UserReservation> getFlightReservation(String flight_id);

    List<UserReservation> getFlightReservation(Flight flight);

    List<Reservation> getUserReservation(String user_id);

    List<Reservation> getUserReservation(User user);

    boolean validateReservation(Reservation reservation);

    boolean validateReservation(String reservation_id);

    boolean unvalidateReservation(Reservation reservation);

    boolean unvalidateReservation(String reservation_id);

    boolean setNotified(Reservation reservation);

    boolean setNotified(String reservation_id);
}
