package dao.database.object_dao;

import dao.database.DataBase;
import metier.Flight;
import metier.Reservation;
import metier.User;
import metier.UserReservation;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.ActionFuture;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.search.MatchQuery;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.elasticsearch.index.query.QueryBuilders.matchQuery;

public class Reservation_dao extends DAO<Reservation> implements Reservation_dao_interface {


    Reservation_dao(DataBase db) {
        super(db, "reservations","reservation", Reservation.class);
    }

    @Override
    public List<UserReservation> getFlightReservation(String flight_id){
        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(QueryBuilders.matchQuery("flight_id", flight_id))
                .get();
        List<Reservation> reservations = mapHits(response);
        List<UserReservation> userReservations = new ArrayList<>();
        for (Reservation reservation : reservations){
            UserReservation userReservation = new UserReservation();
            User user = DAO_factory.getUserDao().find(reservation.getUser_id());
            userReservation.setReservation_id(reservation.getId());
            userReservation.setNbrPlace(reservation.getNumber_of_place());
            userReservation.setUser_id(reservation.getUser_id());
            userReservation.setUser_name(user.getName());
            userReservation.setUser_first_name(user.getFirst_name());
            userReservation.setUser_email(user.getEmail());
            userReservation.setValidate(reservation.getValidate());
            userReservations.add(userReservation);
        }
        return userReservations;
    }

    @Override
    public List<UserReservation> getFlightReservation(Flight flight){
        return getFlightReservation(flight.getId());
    }

    @Override
    public List<Reservation> getUserReservation(String user_id) {
        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(QueryBuilders.matchQuery("user_id", user_id))
                .setSize(10000)
                .get();
        return mapHits(response);
    }

    @Override
    public List<Reservation> getUserReservation(User user) {
        return getUserReservation(user.getId());
    }

    @Override
    public boolean validateReservation(Reservation reservation){
        reservation.setValidate(1);
        return update(reservation);
    }

    @Override
    public boolean validateReservation(String reservation_id){
        return validateReservation(find(reservation_id));
    }

    @Override
    public boolean unvalidateReservation(Reservation reservation){
        reservation.setValidate(0);
        return update(reservation);
    }

    @Override
    public boolean unvalidateReservation(String reservation_id){
        return unvalidateReservation(find(reservation_id));
    }

    @Override
    public boolean setNotified(Reservation reservation){
        reservation.setNotified(true);
        return update(reservation);
    }

    @Override
    public boolean setNotified(String reservation_id){
        return setNotified(find(reservation_id));
    }
}
