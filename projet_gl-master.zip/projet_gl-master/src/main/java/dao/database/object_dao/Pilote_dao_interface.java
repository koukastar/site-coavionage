package dao.database.object_dao;

import metier.Pilote;

public interface Pilote_dao_interface extends Person_dao_interface<Pilote> {

}
