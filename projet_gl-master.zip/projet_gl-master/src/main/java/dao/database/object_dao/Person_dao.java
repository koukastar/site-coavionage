package dao.database.object_dao;

import dao.database.DataBase;
import metier.Person;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilders;

public abstract class Person_dao<T extends Person> extends DAO<T> implements Person_dao_interface<T> {

    public Person_dao(DataBase db, String index, String type, Class<T> tClass) {
        super(db, index, type, tClass);
    }

    @Override
    public T find(String email, String password) {
        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(new BoolQueryBuilder()
                        .must(QueryBuilders.multiMatchQuery(email, "email")
                                .operator(Operator.AND))
                        .must(QueryBuilders.multiMatchQuery(password, "password"))
                ).get();
        return mapHit(response);
    }

    @Override
    public void setToken(String user_id, String token){
        T person = find(user_id);
        if (person != null){
            person.setToken(token);
            update(person);
        }else{
            // exception
        }
    }

    @Override
    public void setToken(T person, String token) {
        person.setToken(token);
        update(person);
    }

    @Override
    public T findByToken(String token) {
        SearchResponse response = db.getClient().prepareSearch(index).setTypes(type)
                .setQuery(QueryBuilders.matchQuery("token", token))
                .get();
        return mapHit(response);
    }

    @Override
    public T removeToken(String token){
        T person = findByToken(token);
        if (person != null){
            person.setToken("");
            update(person);
        }
        return person;
    }
}
