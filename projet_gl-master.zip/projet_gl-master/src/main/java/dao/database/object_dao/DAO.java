package dao.database.object_dao;


import dao.database.DataBase;
import metier.Metier;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchHit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public abstract class DAO<T extends Metier> {

    protected DataBase db;

    protected String index;

    protected String type;

    protected Class<T> tClass;

    public DAO(DataBase db, String index, String type, Class<T> tClass) {
        this.db = db;
        this.index = index;
        this.type = type;
        this.tClass = tClass;
    }

    /**
     * Méthode de création
     *
     * @return boolean
     */
    public String create(T obj){
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String object = objectMapper.writeValueAsString(obj);

            IndexResponse resp = db.getClient().prepareIndex(index, type)
                    .setSource(object, XContentType.JSON)
                    .get();
            if(!resp.getId().equals("")){
                obj.setId(resp.getId());
                update(obj);
                return resp.getId();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @return boolean
     */
    public boolean delete(String id){
        DeleteResponse response = db.getClient().prepareDelete(index, type, id).get();
        return response.status().getStatus() == 200;
    }

    /**
     * Méthode pour effacer
     *
     * @return boolean
     */
    public boolean delete(T obj){
        return delete(obj.getId());
    }


    /**
     * Méthode de mise à jour
     *
     * @param obj
     * @return boolean
     */
    public boolean update(T obj){
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String object = objectMapper.writeValueAsString(obj);
            UpdateRequest resp = new UpdateRequest(index,type,obj.getId());
            resp.doc(object, XContentType.JSON);
            db.getClient().update(resp).get();
            return true;
        } catch (IOException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Méthode de recherche des informations
     *
     * @return T
     */
    public T find(String id) {
        GetResponse response = db.getClient().prepareGet(index, type, id).get();
        ObjectMapper mapper = new ObjectMapper();
        T obj = null;
        try {
            obj = mapper.readValue(response.getSourceAsString(), tClass);
            obj.setId(response.getId());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return obj;
    }

    public List<T> getAll() {
        SearchResponse resp = db.getClient().prepareSearch(index).setTypes(type).get();
        return mapHits(resp, tClass);
    }

    protected T mapHit(SearchResponse response, Class<T> valueType){
        List<SearchHit> searchHits = Arrays.asList(response.getHits().getHits());
        ObjectMapper mapper = new ObjectMapper();
        T obj;
        if (searchHits.size() < 1) return null;
        try {
            obj = mapper.readValue(searchHits.get(0).getSourceAsString(), valueType);
            obj.setId(searchHits.get(0).getId());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return obj;
    }

    protected T mapHit(SearchResponse response){
        return mapHit(response, tClass);
    }

    protected List<T> mapHits(SearchResponse response, Class<T> valueType){
        List<SearchHit> searchHits = Arrays.asList(response.getHits().getHits());
        List<T> results = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        searchHits.forEach(
                hit -> {
                    try {
                        T obj = mapper.readValue(hit.getSourceAsString(), valueType);
                        obj.setId(hit.getId());
                        results.add(obj);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        return results;
    }

    protected List<T> mapHits(SearchResponse response){
        return mapHits(response, tClass);
    }
}

