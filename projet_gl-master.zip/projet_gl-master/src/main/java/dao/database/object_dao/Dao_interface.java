package dao.database.object_dao;

import java.util.List;

public interface Dao_interface<T> {

    String create(T obj);

    boolean update(T obj);

    boolean delete(T obj);

    boolean delete(String id);

    T find(String id);

    List<T> getAll();

}
