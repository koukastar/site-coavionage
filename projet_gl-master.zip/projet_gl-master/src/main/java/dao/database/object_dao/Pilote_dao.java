package dao.database.object_dao;

import dao.database.DataBase;

import metier.Pilote;

public class Pilote_dao extends Person_dao<Pilote> implements Pilote_dao_interface{


    Pilote_dao(DataBase db) {
        super(db, "pilotes", "pilote", Pilote.class);
    }



}
