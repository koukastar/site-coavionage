package dao.database.object_dao;

import dao.database.DataBase;
import metier.User;


public class User_dao extends Person_dao<User> implements User_dao_interface {

    User_dao(DataBase db) {
        super(db, "users", "user", User.class);
    }
}
