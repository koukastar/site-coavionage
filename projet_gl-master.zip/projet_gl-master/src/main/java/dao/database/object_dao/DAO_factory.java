package dao.database.object_dao;

import dao.database.DataBase;
import dao.database.Elastic_DataBase;

public class DAO_factory {

    private static DataBase db = Elastic_DataBase.getConnection();

    public static Flight_dao_interface getFlightDao(){
        return new Flight_dao(db);
    }

    public static User_dao_interface getUserDao(){
        return new User_dao(db);
    }

    public static Pilote_dao_interface getPiloteDao(){
        return new Pilote_dao(db);
    }

    public static Reservation_dao_interface getReservationDao(){
        return new Reservation_dao(db);
    }
}
