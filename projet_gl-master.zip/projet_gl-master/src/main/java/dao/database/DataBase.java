package dao.database;


import org.elasticsearch.client.transport.TransportClient;

public interface DataBase {

    TransportClient getClient();

}

