package dao.database;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.ResultSetMetaData;


public class Elastic_DataBase implements DataBase {


    private final String host = "127.0.0.1";
    private final int port = 9300;

    private TransportClient client;
    private static Elastic_DataBase instance;

    private Elastic_DataBase() {
        this.client = getClient();
    }

    public TransportClient getClient() {
        if(this.client ==null){
            try {
                client = new PreBuiltTransportClient(Settings.EMPTY)
                        .addTransportAddress(new TransportAddress(InetAddress.getByName(host), port));
                if (client.connectedNodes().isEmpty()) {
                    System.out.println("Can't access to database");
                }
            } catch (UnknownHostException ex) {
                ex.printStackTrace();
            }
        }
        return client;
    }


    public static DataBase getConnection() {
        if (instance == null) {
            instance = new Elastic_DataBase();
        }
        return instance;
    }

    public static void connect(){
        getConnection();
    }
}
