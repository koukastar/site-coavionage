package com.example.jetty_jersey.mail.mail_types;

import metier.Flight;
import metier.User;

public class MailReservationPilot extends MailContentNotify {
	
	public MailReservationPilot(User user, Flight flight) {
		super(user, flight);
		this.object = "New reservation for the </depart/> - </arrivee/> flight";
		this.content = "<p></pilot/>, a reservation was made by </user/> for the" +
				" </date/> </depart/> - </arrivee/> flight .<p>";
	}

}
