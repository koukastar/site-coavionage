package com.example.jetty_jersey.ws.filters;

public enum Role {
    PILOT,
    USER
}
