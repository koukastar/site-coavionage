package com.example.jetty_jersey.mail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.example.jetty_jersey.mail.mail_types.MailContent;
import com.example.jetty_jersey.mail.mail_types.MailFlightReminder;
import com.example.jetty_jersey.mail.mail_types.MailReservationAcceptee;
import com.example.jetty_jersey.mail.mail_types.MailReservationPilot;
import com.example.jetty_jersey.mail.mail_types.MailReservationRefusee;
import com.example.jetty_jersey.mail.mail_types.MailReservationUser;

import dao.database.object_dao.DAO_factory;
import metier.Flight;
import metier.Reservation;
import metier.User;

public class MailSender {
	private final static String from = "noreply.flywithme@gmail.com";
	private final static String pwd = "kaqerrvxnysbgspp";
	private final static String host = "smtp.gmail.com";

	static Properties setProp () {
		int port = 587;
		Properties prop = System.getProperties();
		// Setup mail server
		prop.setProperty("mail.smtp.host", host);
		prop.put("mail.smtp.starttls.enable", "true");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.port", port);
		return prop;
	}
	
	//JokerInSmash...ItHasBeen4000Years...
	private static final DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(sdf.format(date));
		
		Date date2 = addDays(new Date(), 31);
		System.out.println(sdf.format(date2));

		Calendar cal = Calendar.getInstance();
		System.out.println(sdf.format(cal.getTime()));

		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));

		LocalDate localDate = LocalDate.now();
		System.out.println(DateTimeFormatter.ofPattern("yyy/MM/dd").format(localDate));
		System.out.println((String) null);
		
		send_msg("oussama_hadj-aissa@hotmail.com", new MailFlightReminder(null)); //poyo97@gmail.com
		System.out.print("fini !");
	}

	public static Date addDays(Date date, int days)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();
    }
	
	public static void send_msg(String to, MailContent mc){
		Properties prop = setProp();
		System.out.println("Properties set");
		Session session = Session.getInstance(prop,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, pwd);
			}
		});
		System.out.println("session ready");
		try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

	         // Set Subject: header field
	         message.setSubject(mc.getObject());
	         System.out.println("subject fetched");
	         
	         // Send the actual HTML message, as big as you like
	         message.setContent(mc.getContent(), "text/html");
	         System.out.println("Content fetched");
	         
	         // Send message
	         Transport.send(message);
	         System.out.println("Sent message successfully....");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
		
	}

	public static void mail_res_depose(Reservation rv) {
        User user = DAO_factory.getUserDao().find(rv.getUser_id());
        Flight flight = DAO_factory.getFlightDao().find(rv.getFlight_id());
		send_msg(user.getEmail(), new MailReservationUser(user, flight));
		send_msg(flight.getPilote().getEmail(), new MailReservationPilot(user, flight));
	}
	
	public static void mail_res_valide(Reservation rv) {
        User user = DAO_factory.getUserDao().find(rv.getUser_id());
        Flight flight = DAO_factory.getFlightDao().find(rv.getFlight_id());
		send_msg(user.getEmail(), new MailReservationAcceptee(user, flight));
	}

	public static void mail_res_refuse(Reservation rv) {
        User user = DAO_factory.getUserDao().find(rv.getUser_id());
        Flight flight = DAO_factory.getFlightDao().find(rv.getFlight_id());
		send_msg(user.getEmail(), new MailReservationRefusee(user, flight));
	}
	
	public static void prepare_notify(Reservation rv) {
        User user = DAO_factory.getUserDao().find(rv.getUser_id());
        Flight flight = DAO_factory.getFlightDao().find(rv.getFlight_id());
		send_msg(user.getEmail(), new MailFlightReminder(flight));
	}
	
	public static void prepare_notify(Flight fl) {
		send_msg(fl.getPilote().getEmail(), new MailFlightReminder(fl));
	}
}
