package com.example.jetty_jersey.mail.mail_types;

import metier.Flight;
import metier.User;

public class MailReservationUser extends MailContentNotify {

	public MailReservationUser(User user, Flight flight) {
		this.object = "Reservation </depart/> - </arrivee/> registered";
		this.content = "<p></user/>, your reservation for the </date/> </depart/> - </arrivee/>" +
				" has been registered, and the pilot will be notified.<p>";
	}

}
