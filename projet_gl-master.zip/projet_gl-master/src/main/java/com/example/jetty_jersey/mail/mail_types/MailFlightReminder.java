package com.example.jetty_jersey.mail.mail_types;

import java.text.SimpleDateFormat;
import java.util.Date;

import metier.Flight;

public class MailFlightReminder extends MailContentNotify {

	public MailFlightReminder(Flight flight) {
		super(null, flight);
		this.object = "Reminder for the </depart/> - </arrivee/> flight";
		this.content = sectionFormat("flight", "vol",true);
	    this.content += sectionFormat("Pilot", "pilote", true);
		this.content += sectionFormat("Date", "date", true);
		this.content += sectionFormat("Meeting Point", "rdv", true);
		this.content += sectionFormat("Departure", "depart", true);
		this.content += sectionFormat("Arrival", "arrivee", true);
	    this.content += sectionFormat("Flight type", "plan", true);
		this.content += sectionFormat("Duration", "duree", true);
		this.content += sectionFormat("Amount of seats", "nbPlaces", true);
	    this.content += sectionFormat("Description", "descr", true);
		this.content += sectionFormat("Price per seat", "prix", false);
	}
	
	private String sectionFormat(String subject, String field, boolean followed) {
		return "<h4>"+ subject +" : </h4></"+ field
				+ ((followed)?"/></br>\n":"/>\n"); 
	}
	
	public String getContent() {
		return content.replaceAll("</vol/>", translateNull(fl.getId()))
				.replaceAll("</pilote/>", translateNull(fl.getPilote().getName()))
				.replaceAll("</date/>", translateNull(fl.getDate()))
				.replaceAll("</rdv/>", translateNull(fl.getPlace_of_meeting()))
				.replaceAll("</depart/>", translateNull(fl.getDeparted_aerodrome()))
				.replaceAll("</arrivee/>", translateNull(fl.getArrival_aerodrome()))
				.replaceAll("</plan/>", translateNull(fl.getPlan_type()))
				.replaceAll("</duree/>", fl.getDuration()+"")
				.replaceAll("</nbPlaces/>", fl.getNumber_of_seats()+"")
				.replaceAll("</descr/>", translateNull(fl.getDescription()))
				.replaceAll("</prix/>", fl.getRate()+"");
	}
}
