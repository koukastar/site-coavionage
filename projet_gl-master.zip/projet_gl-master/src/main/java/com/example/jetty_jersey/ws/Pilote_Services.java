package com.example.jetty_jersey.ws;

import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.Pilote_dao_interface;
import metier.Flight;
import metier.Pilote;
import metier.Reservation;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import utils.PasswordUtil;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.*;
import java.text.NumberFormat;
import java.util.List;

@Path("pilotes")
public class Pilote_Services {
    private Pilote_dao_interface dao = DAO_factory.getPiloteDao();
    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Pilote> getAll() {
        return dao.getAll();

    }
    
    @GET
    @Path("/pilote/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Pilote get(@PathParam("id") String id) {
        return dao.find(id);
    }

    @POST
    @Path("/create")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPilote(Pilote pl) {
        pl.setPassword(PasswordUtil.getSecurePassword(pl.getPassword()));
        pl.setType("pilote");
        dao.create(pl);
    	return Response.ok().entity(pl).build();
    }
    
    @DELETE
    @Path("/delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean removePilote(@PathParam("id") String id) {
    	Pilote pl = dao.find(id);
    	if(pl != null)
    		return dao.delete(pl);
    	return false;
    }

    @POST
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
	public boolean update(Pilote pl) {
        return dao.update(pl);
	}

    @POST
    @Path("/image/upload/{id}")
    @Consumes({MediaType.MULTIPART_FORM_DATA})
    public Response uploadImage(@PathParam("id") String piloteId,  @FormDataParam("file") InputStream fileInputStream,
                                    @FormDataParam("file") FormDataContentDisposition fileMetaData)  {
        String Type = fileMetaData.getFileName().substring(fileMetaData.getFileName().indexOf('.'));
         String filename="uploads/"+piloteId+Type;
        try {
            OutputStream out = new FileOutputStream(new File(filename));
            int read = 0;
            byte[] bytes = new byte[1024];
            out = new FileOutputStream(new File(filename));
            while ((read = fileInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();
            out.close();
        } catch (IOException e) {

            e.printStackTrace();
        }
        return Response.ok(filename + " uploaded successfully !!").build();
    }

    @GET
    @Path("/image/{filename}")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response downloadFilebyPath(@PathParam("filename") String fileName) {
        String fileLocation = "uploads/"+fileName+".jpg";
        Response response = null;
        NumberFormat myFormat = NumberFormat.getInstance();
        myFormat.setGroupingUsed(true);
        File file = new File( fileLocation);
        if (file.exists()) {
            Response.ResponseBuilder builder = Response.ok(file);
            builder.header("Content-Disposition", "attachment; filename=" + file.getName());
            response = builder.build();
            System.out.println(" envoie");
        } else {
            File notFound = new File( "uploads/notFound.JPG");
            Response.ResponseBuilder builder = Response.ok(notFound);
            builder.header("Content-Disposition", "attachment; filename=" + notFound.getName());
            response = builder.build();}
        return response;
    }


    @GET
    @Path("/getToken/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public Pilote getByToken(@PathParam("token") String token ){
        return dao.findByToken(token);
    }
}
