package com.example.jetty_jersey.ws;

import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.Pilote_dao_interface;
import dao.database.object_dao.User_dao_interface;
import metier.Pilote;
import metier.User;

import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;


@Path("/logout")
public class Logout {

    @GET
    @Path("/user")
    public Response logoutUser(@CookieParam("token") String token, @Context HttpHeaders httpHeaders) {

        System.out.println("httpHeaders.getCookies() = " + httpHeaders.getCookies());
        //TODO getUserByToken and replace token by null in DB

        User_dao_interface userDAO = DAO_factory.getUserDao();
        System.out.println("token = " + token);

        User user = userDAO.removeToken(token);
        System.out.println("user = " + user);

        NewCookie tokenCookie = new NewCookie("token", null, "/", "",
                "token", 0, false);
        NewCookie firstNameCookie = new NewCookie("firstName", null, "/",
                "", "firstName", 0, false);

        NewCookie typeCookie = new NewCookie("type",user.getType(),"/",
                "", "type", 0, false);
        return Response.ok()
                .cookie(tokenCookie)
                .cookie(firstNameCookie).cookie(typeCookie)
                .build();
    }


    @GET
    @Path("/pilote")
    public Response logoutPilot(@CookieParam("token") String token, @Context HttpHeaders httpHeaders) {
        //TODO getUserByToken and replace token by null in DB
        System.out.println("httpHeaders.getCookies() = " + httpHeaders.getCookies());

        Pilote_dao_interface userDAO = DAO_factory.getPiloteDao();
        System.out.println("token = " + token);

        Pilote pilote = userDAO.removeToken(token);
        System.out.println("pilote = " + pilote);

        NewCookie tokenCookie = new NewCookie("token", null, "/", "",
                "token", 0, false);
        NewCookie firstNameCookie = new NewCookie("firstName", null, "/",
                "", "firstName", 0, false);

        NewCookie typeCookie = new NewCookie("type",pilote.getType(),"/",
                "", "type", 0, false);
        return Response.ok()
                .cookie(tokenCookie)
                .cookie(firstNameCookie).cookie(typeCookie)
                .build();
    }

}
