
package com.example.jetty_jersey.mail;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.annotation.WebListener;

import org.eclipse.jetty.util.thread.ScheduledExecutorScheduler;

@WebListener
public class BackgroundJobManager extends ScheduledExecutorScheduler {

    private ScheduledExecutorService scheduler;

    @Override
    public void doStart() {
        System.out.println("Start.");
        scheduler = Executors.newSingleThreadScheduledExecutor();
        //scheduler.scheduleAtFixedRate(new SomeDailyJob(), 0, 1, TimeUnit.DAYS);
        //scheduler.scheduleAtFixedRate(new SomeHourlyJob(), 0, 1, TimeUnit.HOURS);
        scheduler.scheduleAtFixedRate(new SomeQuarterlyJob(), 0, 15, TimeUnit.MINUTES);
    }

    @Override
    public void doStop() {
        System.out.println("Shutdown.");
        scheduler.shutdownNow();
    }

}