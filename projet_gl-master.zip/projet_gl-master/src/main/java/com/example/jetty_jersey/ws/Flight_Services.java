package com.example.jetty_jersey.ws;

import dao.database.object_dao.*;
import jdk.nashorn.internal.objects.NativeUint8Array;
import metier.*;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import utils.Search;

import javax.validation.constraints.Null;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

@Path("/flights")
public class Flight_Services {

    private Flight_dao_interface dao = DAO_factory.getFlightDao();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Flight> getFlights()
    {
        List list = dao.getAll();
        System.out.println("list = " + list);
        return list;
    }

    @GET
    @Path("flight/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Flight getFlight(@PathParam("id") String id)
    {
        return dao.find(id);
    }

    @GET
    @Path("/getPilotes/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Flight> getFlightPilotes(@PathParam("token") String tokenPilote)
    {
        System.out.println("tokenPilote = " + tokenPilote);
        System.out.println("DAO_factory.getPiloteDao().findByToken() = " +
                DAO_factory.getPiloteDao().findByToken(tokenPilote).getId());
        return dao.getFlightsPilote(DAO_factory.getPiloteDao().findByToken(tokenPilote).getId());
    }


    @POST
    @Path("create/{token}")
    public HashMap<String, String> createFlight(Flight flight, @PathParam("token") String tokenPilote) {
        Pilote pilote;
        Pilote_dao_interface dao_factory= DAO_factory.getPiloteDao();
        pilote=dao_factory.findByToken(tokenPilote);
        flight.setPilote(pilote);
        System.out.println("flight = " + flight);
        String id = dao.create(flight);
        HashMap<String , String> map = new HashMap<>();
        map.put("id", id);
        return map;
    }

    @POST
    @Path("update")
    public boolean update(Flight flight) {
        return dao.update(flight);
    }

    @DELETE
    @Path("delete/{id}")
    public boolean DeleteFlight(@PathParam("id") String id) {
        Flight flight = dao.find(id);
        if (flight != null)
            return dao.delete(flight);
        return false;
    }

    @GET
    @Path("/search")
    public List<Flight> searchFlights(
            @DefaultValue("") @QueryParam("departed_aerodrome") String departed_aerodrome,
            @DefaultValue("") @QueryParam("arrival_aerodrome") String arrival_aerodrome,
            @QueryParam("duration") int number_of_seats,
            @DefaultValue("") @QueryParam("date") String date) {
        Search s = new Search();
        s.setDeparted_aerodrome(departed_aerodrome);
        s.setArrival_aerodrome(arrival_aerodrome);
        s.setNumber_of_seats(number_of_seats);
        s.setDate(date);
        List<Flight> f = dao.searchFlight(s);
        for (Flight ff : f) {
            System.out.println(ff);
        }
        return dao.searchFlight(s);
    }


    @GET
    @Path("/demandeur/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<UserReservation> demandeurReservation(@PathParam("id") String idFlight) {
        System.out.println(idFlight);
        return DAO_factory.getReservationDao().getFlightReservation(idFlight);
    }


    public List<Flight> getPiloteFlights(String id_pilote){
        return dao.getFlightsPilote(id_pilote);
    }

}