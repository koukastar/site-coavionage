package com.example.jetty_jersey.mail.mail_types;

import metier.Flight;
import metier.User;

public class MailReservationAcceptee extends MailContentNotify {

	public MailReservationAcceptee(User user, Flight flight) {
		super(user, flight);
		this.object = "Reservation confirmed";
		this.content = "<p></user/>, your reservation for the </date/> </depart/> - </arrivee/> flight has been accepted.</p>";
	}
	
}
