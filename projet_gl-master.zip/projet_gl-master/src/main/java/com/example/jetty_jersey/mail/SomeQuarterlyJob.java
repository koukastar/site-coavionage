package com.example.jetty_jersey.mail;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.Flight_dao_interface;
import metier.Flight;
import metier.Reservation;

public class SomeQuarterlyJob implements Runnable {

    public static int count = 0;

    @Override
    public void run() {
        test();
    }

    private static void test() {
        checkReservations();
    }

    private static void checkReservations() {
        Flight_dao_interface dao = DAO_factory.getFlightDao();
        List<Flight> li = dao.getAll();
        Date date = addDays(new Date(), 2);
        for (Flight fl : li) {
            if (new Date(fl.getDate()).before(date) && new Date(fl.getDate()).after(new Date())) {
                if (!fl.isNotified()) {
                    MailSender.prepare_notify(fl);
                    dao.setNotified(fl);
                }
                for (Reservation rv : fl.getReservations()) {
                    if (!rv.isNotified()) {
                        MailSender.prepare_notify(rv);
                        DAO_factory.getReservationDao().setNotified(rv);
                    }
                }
            }
        }
    }

    private static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();
    }

}
