package com.example.jetty_jersey.mail.mail_types;

public class MailContent {
	
	protected String object;
	protected String content;
	
	public MailContent() {
		object = "This is the Subject Line!";
		content = "<p>This is an actual message from nobody.</p>";
	}
	
	public String getObject() {
		return object;
	}

	public String getContent() {
		return content;
	}

}
