package com.example.jetty_jersey.mail.mail_types;

import metier.Flight;
import metier.Pilote;
import metier.User;

public class MailContentNotify extends MailContent {

	protected User us;
	protected Flight fl;
	
	public MailContentNotify(){
		super();
		us = new User();
		fl = new Flight();
	}
	
	public MailContentNotify(User us, Flight fl){
		super();
		if (us == null) this.us = new User();
		else this.us = us;
		if (fl == null) {
			this.fl = new Flight();
			this.fl.setPilote(new Pilote());
		}
		else this.fl = fl;
	}
	

	@Override
	public String getObject() {
		return object.replaceAll("</depart/>", translateNull(fl.getDeparted_aerodrome()))
                .replaceAll("</arrivee/>", translateNull(fl.getArrival_aerodrome()));
	}

	@Override
	public String getContent() {
		return content.replaceAll("</pilot/>", translateNull(fl.getPilote().getName()))
				.replaceAll("</user/>", translateNull(us.getName()))
				.replaceAll("</depart/>", translateNull(fl.getDeparted_aerodrome()))
				.replaceAll("</arrivee/>", translateNull(fl.getArrival_aerodrome()))
                .replaceAll("</date/>", translateNull(fl.getDate()));
	}
	
	
	protected String translateNull(Object s) {
		return (s == null)?"Null":s.toString();
	}
	
}
