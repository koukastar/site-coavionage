package com.example.jetty_jersey.mail.mail_types;

import metier.Flight;
import metier.User;

public class MailReservationRefusee extends MailContentNotify {

	public MailReservationRefusee(User user, Flight flight) {
		super(user, flight);
		this.object = "Reservation rejected";
		this.content = "<p></user/>, your reservation for the </date/> </depart/> - </arrivee/> flight has been rejected.</p>";
	}

}
