package com.example.jetty_jersey.ws;

import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.Pilote_dao_interface;
import dao.database.object_dao.User_dao_interface;
import utils.Credentials;
import metier.Pilote;
import metier.User;
import utils.PasswordUtil;

import javax.security.auth.login.CredentialException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Path("/login")
public class Login {

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/user")
    public Response authenticateUser(Credentials credentials) {
        try {
            System.out.println("credentials = " + credentials);
            User user = verifyUser(credentials);
            System.out.println("user = " + user);
            String token = issueToken(credentials.getEmail());
            System.out.println("token = " + token);
            user.setToken(token);

            System.out.println("user = " + user);
            User_dao_interface userDao = DAO_factory.getUserDao();
            userDao.update(user);

            NewCookie tokenCookie = new NewCookie("token", token, "/", "", "token",
                    100000, false);
            NewCookie firstNameCookie = new NewCookie("firstName", user.getFirst_name(), "/",
                    "", "firstName", 100000, false);
            NewCookie typeCookie = new NewCookie("type", user.getType(), "/",
                    "", "type", 100000, false);

            return Response.ok()
                    .cookie(tokenCookie)
                    .cookie(firstNameCookie).cookie(typeCookie)
                    .build();
        } catch (Exception e) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pilote")
    public Response authenticatePilot(Credentials credentials) {
        try {
            System.out.println("credentials = " + credentials);
            Pilote pilote = verifyPilot(credentials);
            System.out.println("pilote = " + pilote);
            String token = issueToken(credentials.getEmail());
            System.out.println("token = " + token);
            pilote.setToken(token);
            System.out.println("PasswordUtil.getSecurePassword(" + pilote.getPassword() + ") = " + PasswordUtil.getSecurePassword("123"));
            System.out.println("pilote = " + pilote);
            Pilote_dao_interface pilote_dao = DAO_factory.getPiloteDao();
            pilote_dao.update(pilote);

            NewCookie tokenCookie = new NewCookie("token", token, "/", "", "token",
                    100000, false);
            NewCookie firstNameCookie = new NewCookie("firstName", pilote.getFirst_name(), "/",
                    "", "firstName", 100000, false);
            NewCookie typeCookie = new NewCookie("type", pilote.getType(), "/",
                    "", "type", 100000, false);

            return Response.ok()
                    .cookie(tokenCookie)
                    .cookie(firstNameCookie).cookie(typeCookie)
                    .build();
        } catch (Exception e) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
    }

    private String issueToken(String username) {
        Random random = new SecureRandom();
        return new BigInteger(130, random).toString();
    }

    private User verifyUser(Credentials credentials) throws CredentialException {
        User_dao_interface userDAO = DAO_factory.getUserDao();
        System.out.println("userDAO = " + userDAO);
        System.out.println("credentials = " + credentials.getEmail());
        System.out.println("credentials = " + credentials.getPassword());

        User user = userDAO.find(credentials.getEmail(), PasswordUtil.getSecurePassword(credentials.getPassword()));

        System.out.println("VerifyUser user.getPassword() = " + user.getPassword());
        System.out.println("user = " + user);
        if (user == null)
            throw new CredentialException("Wrong username or password");

        return user;
    }


    private Pilote verifyPilot(Credentials credentials) throws CredentialException {
        Pilote_dao_interface pilotDAO = DAO_factory.getPiloteDao();
        Pilote pilot = pilotDAO.find(credentials.getEmail(), PasswordUtil
                .getSecurePassword(credentials.getPassword()));

        if (pilot == null)
            throw new CredentialException("Wrong username or password");

        return pilot;
    }


}
