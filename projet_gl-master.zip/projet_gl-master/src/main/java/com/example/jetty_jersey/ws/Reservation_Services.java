package com.example.jetty_jersey.ws;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.print.attribute.standard.Media;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.example.jetty_jersey.mail.MailSender;
import com.example.jetty_jersey.mail.mail_types.MailReservationAcceptee;
import com.example.jetty_jersey.mail.mail_types.MailReservationPilot;
import com.example.jetty_jersey.mail.mail_types.MailReservationRefusee;
import com.example.jetty_jersey.mail.mail_types.MailReservationUser;
import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.Reservation_dao_interface;
import metier.Reservation;
import metier.User;
import metier.UserReservation;

@Path("reservations")
public class Reservation_Services {

    private Reservation_dao_interface dao = DAO_factory.getReservationDao();

    @PUT
    @Path("/create")
    @Produces(MediaType.APPLICATION_JSON)
    public void createReservation(Reservation rv) {
        dao.create(rv);
    }

    @DELETE
    @Path("/delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public void deleteReservation(@PathParam("id") String id) {
        Reservation rv = dao.find(id);
        if (rv != null)
            dao.delete(rv);
    }

    @GET
    @Path("/flight/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<UserReservation> findByFlight(@PathParam("id") String id) {
        return dao.getFlightReservation(id);
    }

    @GET
    @Path("/user/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Reservation> findByUser(@PathParam("id") String id) {
        return dao.getUserReservation(id);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Reservation> getAllReservations() {
        return dao.getAll();
    }

    @GET
    @Path("/reservation/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Reservation getReservations(@PathParam("id") String id) {
        return dao.find(id);
    }

    @POST
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean update(Reservation rv) {
        return dao.update(rv);
    }


    @POST
    @Path("/createReservation")
    @Produces(MediaType.APPLICATION_JSON)
    public Reservation createReservation(@QueryParam("idUser") String idUser,
                                         @QueryParam("nbPlace") int nbPlace,
                                         @QueryParam("idFlight") String idFlight) {
        Reservation reservation = new Reservation(nbPlace, idFlight, idUser);
        dao.create(reservation);
        System.out.println(idUser + " " + nbPlace + " " + idFlight);

        MailSender.send_msg(
                DAO_factory.getFlightDao().find(reservation.getFlight_id()).getPilote().getEmail(),
                new MailReservationPilot(
                        DAO_factory.getUserDao().find(reservation.getUser_id()),
                        DAO_factory.getFlightDao().find(reservation.getFlight_id())
                )
        );

        MailSender.send_msg(
                DAO_factory.getUserDao().find(reservation.getUser_id()).getEmail(),
                new MailReservationUser(
                        DAO_factory.getUserDao().find(reservation.getUser_id()),
                        DAO_factory.getFlightDao().find(reservation.getFlight_id())
                )
        );
        return reservation;
    }


    public List<UserReservation> getFlightReservation(String flight_id) {
        return dao.getFlightReservation(flight_id);
    }

    @POST
    @Path("/validete")
    @Produces(MediaType.APPLICATION_JSON)
    public Response validation(@QueryParam("idReservation") String idReservation) {
        dao.validateReservation(idReservation);
        Reservation reservation = dao.find(idReservation);
        MailSender.send_msg(
                DAO_factory.getUserDao().find(reservation.getUser_id()).getEmail(),
                new MailReservationAcceptee(
                        DAO_factory.getUserDao().find(reservation.getUser_id()),
                        DAO_factory.getFlightDao().find(reservation.getFlight_id())
                )
        );
        return Response.ok().build();
    }

    @POST
    @Path("/unvalidate")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean supprimer(@QueryParam("idReservation") String idReservation) {
        dao.unvalidateReservation(idReservation);
        Reservation reservation = dao.find(idReservation);
        MailSender.send_msg(
                DAO_factory.getUserDao().find(reservation.getUser_id()).getEmail(),
                new MailReservationRefusee(
                        DAO_factory.getUserDao().find(reservation.getUser_id()),
                        DAO_factory.getFlightDao().find(reservation.getFlight_id())
                )
        );
        return true;
    }

}
