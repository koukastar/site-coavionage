package com.example.jetty_jersey.mail;

public class SomeDailyJob implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
