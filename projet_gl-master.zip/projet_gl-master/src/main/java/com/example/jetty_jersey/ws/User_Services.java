package com.example.jetty_jersey.ws;

import java.util.*;


import javax.print.attribute.standard.Media;
import javax.ws.rs.*;
import javax.ws.rs.core.*;


import dao.database.object_dao.DAO_factory;
import dao.database.object_dao.User_dao_interface;
import metier.User;
import org.glassfish.jersey.internal.inject.HttpHeadersInjectee;
import utils.PasswordUtil;


@Path("users")
public class User_Services {


    private User_dao_interface dao = DAO_factory.getUserDao();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List getUsers() {
        return dao.getAll();
    }

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public List<User> deleteUser(User user) {
        dao.delete(user);
        return null;
    }

    @POST
    @Path("/create")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createUsers(User user) {
        user.setPassword(PasswordUtil.getSecurePassword(user.getPassword()));
        user.setType("user");
        String id = dao.create(user);
        user.setId(id);
        return Response.ok().entity(user).build();
    }

    @GET
    @Path("search/{id}")
    public User getUserById(
            @DefaultValue("tuxpoWkBqqOIHz199P_7") @PathParam("id") String id) {
        System.out.println(dao.find(id).toString());

        return dao.find(id);
    }


    @GET
    @Path("/search")
    public Response getUserByMail(
            @DefaultValue("email") @QueryParam("email") String email,
            @DefaultValue("password") @QueryParam("password") String password) {
        dao.find(email, password);

        return Response
                .status(200)
                .entity("your flight is , email : " + email + ", password : " + password).build();
    }

    @PUT
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean update(User us) {
        return dao.update(us);
    }


    @GET
    @Path("/user/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public User getByID(@PathParam("id") String id) {
        return dao.find(id);
    }


    @GET
    @Path("/getToken/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public User getByToken(@PathParam("token") String token ){
        return dao.findByToken(token);
    }
}
